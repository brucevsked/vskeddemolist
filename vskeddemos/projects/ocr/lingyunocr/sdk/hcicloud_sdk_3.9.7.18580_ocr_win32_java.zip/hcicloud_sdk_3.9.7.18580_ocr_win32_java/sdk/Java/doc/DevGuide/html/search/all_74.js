var searchData=
[
  ['tts_e8_83_bd_e5_8a_9b',['TTS能力',['../hci_tts_intro_page.html',1,'hci_dev_capability_api']]],
  ['tts_e8_83_bd_e5_8a_9b_e6_8f_8f_e8_bf_b0',['TTS能力描述',['../hci_tts_page.html',1,'caplist_page']]],
  ['tts_e6_92_ad_e6_94_be_e5_99_a8',['TTS播放器',['../hci_tts_player_intro_page.html',1,'hci_dev_ext_api']]]
];
