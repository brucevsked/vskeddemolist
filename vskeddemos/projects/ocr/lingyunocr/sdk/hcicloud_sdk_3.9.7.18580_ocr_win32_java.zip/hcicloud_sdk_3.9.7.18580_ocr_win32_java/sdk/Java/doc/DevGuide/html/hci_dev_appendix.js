var hci_dev_appendix =
[
    [ "能力列表", "caplist_page.html", "caplist_page" ],
    [ "音频编解码库", "codec_intro_page.html", [
      [ "1. 简介", "codec_intro_page.html#codec_common", null ],
      [ "2. TTS音频压缩", "codec_intro_page.html#codec_for_tts", null ],
      [ "3. ASR和VPR音频压缩", "codec_intro_page.html#codec_for_asr", null ]
    ] ],
    [ "应用渠道列表", "app_channel.html", null ]
];