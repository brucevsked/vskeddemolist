var searchData=
[
  ['ocr_e6_8b_8d_e7_85_a7_e5_99_a8',['OCR拍照器',['../hci_ocr_capture_intro_page.html',1,'hci_dev_ext_api']]],
  ['ocr_e8_83_bd_e5_8a_9b',['OCR能力',['../hci_ocr_intro_page.html',1,'hci_dev_capability_api']]],
  ['ocr_e8_83_bd_e5_8a_9b_e6_8f_8f_e8_bf_b0',['OCR能力描述',['../hci_ocr_page.html',1,'caplist_page']]]
];
