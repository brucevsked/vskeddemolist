var caplist_page =
[
    [ "ASR能力描述", "hci_asr_page.html", [
      [ "能力列表", "hci_asr_page.html#capkey_detail", null ],
      [ "Intel MKL库", "hci_asr_page.html#hci_asr_intel_mkl", null ]
    ] ],
    [ "TTS能力描述", "hci_tts_page.html", null ],
    [ "HWR能力描述", "hci_hwr_page.html", [
      [ "能力列表", "hci_hwr_page.html#capkey_detail", null ],
      [ "通用范围", "hci_hwr_page.html#common_recogrange", null ],
      [ "笔势列表", "hci_hwr_page.html#gestures_list", null ],
      [ "语种列表", "hci_hwr_page.html#sublang_list", null ]
    ] ],
    [ "OCR能力描述", "hci_ocr_page.html", [
      [ "能力列表", "hci_ocr_page.html#capkey_detail", null ],
      [ "模板列表", "hci_ocr_page.html#ocr_templates", null ]
    ] ],
    [ "MT能力描述", "hci_mt_page.html", null ],
    [ "NLU能力描述", "hci_nlu_page.html", null ],
    [ "KB能力描述", "hci_kb_page.html", null ],
    [ "VPR能力描述", "hci_vpr_page.html", [
      [ "Intel MKL库", "hci_vpr_page.html#hci_vpr_intel_mkl", null ]
    ] ],
    [ "FPR能力描述", "hci_fpr_page.html", null ]
];