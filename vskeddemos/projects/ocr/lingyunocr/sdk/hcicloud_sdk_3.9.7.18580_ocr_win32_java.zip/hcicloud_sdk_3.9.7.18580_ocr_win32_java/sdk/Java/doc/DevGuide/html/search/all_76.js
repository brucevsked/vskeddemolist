var searchData=
[
  ['vpr_e8_83_bd_e5_8a_9b',['VPR能力',['../hci_vpr_intro_page.html',1,'hci_dev_capability_api']]],
  ['vpr_e8_83_bd_e5_8a_9b_e6_8f_8f_e8_bf_b0',['VPR能力描述',['../hci_vpr_page.html',1,'caplist_page']]]
];
