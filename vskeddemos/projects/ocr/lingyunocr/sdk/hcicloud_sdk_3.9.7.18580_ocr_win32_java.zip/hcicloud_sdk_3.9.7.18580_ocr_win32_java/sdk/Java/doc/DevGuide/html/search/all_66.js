var searchData=
[
  ['fpr_e8_83_bd_e5_8a_9b',['FPR能力',['../hci_fpr_intro_page.html',1,'hci_dev_capability_api']]],
  ['fpr_e8_83_bd_e5_8a_9b_e6_8f_8f_e8_bf_b0',['FPR能力描述',['../hci_fpr_page.html',1,'caplist_page']]]
];
