var searchData=
[
  ['asr_e8_83_bd_e5_8a_9b',['ASR能力',['../hci_asr_intro_page.html',1,'hci_dev_capability_api']]],
  ['asr_e8_83_bd_e5_8a_9b_e6_8f_8f_e8_bf_b0',['ASR能力描述',['../hci_asr_page.html',1,'caplist_page']]],
  ['asr_e5_bd_95_e9_9f_b3_e6_9c_ba',['ASR录音机',['../hci_asr_recorder_intro_page.html',1,'hci_dev_ext_api']]],
  ['android_e5_b9_b3_e5_8f_b0',['Android平台',['../prepare_android_intro_page.html',1,'prepare_intro_page']]]
];
