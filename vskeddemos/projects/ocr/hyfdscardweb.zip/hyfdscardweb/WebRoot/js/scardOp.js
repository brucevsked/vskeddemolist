function setConectMsg(mid,myUrl){
	$.ajax({
		type: 'POST',
		url: myUrl,
		data: 'miId='+mid,
		success: function(dt){
			str='';
			str+='提交人'+dt.usNameA1;
			if(dt.usNickA1!=undefined) str+='|用户'+dt.usNickA1;
			if(dt.usMobileA1!=undefined) str+='|手机'+dt.usMobileA1;
			if(dt.usQqA1!=undefined) str+='|qq'+dt.usQqA1;
			if(dt.addTime!=undefined) str+='|提交时间'+fd(dt.addTime);
			if(dt.adminProcTime!=undefined) str+='|处理时间'+fd(dt.adminProcTime);
			str+=',';
			
			if(dt.usNameA2!=undefined) str+='|管理员'+dt.usNameA2;
			if(dt.usNickA2!=undefined) str+='|管理员用户'+dt.usNickA2;
			if(dt.usMobileA2!=undefined) str+='|手机'+dt.usMobileA2;
			if(dt.usQqA2!=undefined) str+='|qq'+dt.usQqA2;
			
			g('conectMsg').innerHTML=str;
		},
		dataType: 'json'
});
	
}
