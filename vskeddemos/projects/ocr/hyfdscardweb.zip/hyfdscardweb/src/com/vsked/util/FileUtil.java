package com.vsked.util;

import com.sinovoice.hcicloudsdk.common.HciErrorCode;
import com.vsked.entity.AccountInfo;
import com.vsked.ocr.HciCloudOcrHelper;
import com.vsked.ocr.HciCloudSysHelper;

public class FileUtil {
	public static String scardInfo="";
	public static String nowStr="";
	public static boolean isInit=false;
	public static int count=1;
	public static AccountInfo mAccountInfo;
	public static String capkey = null;
	public static HciCloudSysHelper mHciCloudSysHelper;
	public static HciCloudOcrHelper mHciCloudOcrHelper = null;
	
	public static String basePath="";
	public static String accountFilePath="";
	
	public static String userInfoPath="";
	public static String xmlFilePath="";
	public static String sourceFileName="";
			
	public static String getBasePath(){
		return FileUtil.class.getResource("/").getPath().substring(1);
	}
	
	public static void procedScard(String myScardFilePath){
		
		basePath=FileUtil.getBasePath();
		accountFilePath=basePath+"data/AccountInfo.txt";
		userInfoPath=basePath+"data";
		xmlFilePath=basePath+"data/templates/IdCard/IDCard_EN.xml";
		sourceFileName=myScardFilePath;
		
		if(!isInit){
		mAccountInfo = AccountInfo.getInstance();
		mAccountInfo.loadAccountInfo(accountFilePath);
		capkey = mAccountInfo.getCapKey();
        mHciCloudSysHelper = HciCloudSysHelper.getInstance();
        mHciCloudOcrHelper = HciCloudOcrHelper.getInstance();
        mHciCloudSysHelper.init(userInfoPath);
    	mHciCloudOcrHelper.init(basePath);
    	isInit=true;
		}
		
        boolean nRet = true;
		// 本地模板识别
		if(capkey.contains("local")) {
			nRet = mHciCloudOcrHelper.templateRecog(sourceFileName,xmlFilePath);// 本地模板识别
			if(!nRet)  {
				System.out.println("local templateRecog failed！");
				reset();
			}				
		}
	}
	
	public static void reset(){
		FileUtil.isInit=false;
		FileUtil.count=1;
		 mHciCloudOcrHelper.release();
		 mHciCloudSysHelper.release();
	}
	
    public static void main(String[] args) {
		System.out.println(getBasePath());
	}
}
