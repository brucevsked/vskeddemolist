package com.vsked.util;

public class FilePathUtil {
	public static final String uploadFileSavePath="/uploadfiles/";

}
